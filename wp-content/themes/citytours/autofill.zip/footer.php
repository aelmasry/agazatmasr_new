<?php
/* Footer Template */
if (!defined('ABSPATH')) {
    exit;
}

global $ct_options;

$page_template = basename(get_page_template());

if ($page_template != "template-full-width-no-footer.php") :
    //    global $epm_options, $current_user;

    get_currentuserinfo();
    $epm_default_email_value = null;
    if (is_user_logged_in()) {
        $epm_default_email_value = $current_user->user_email;
    }
?>
    <div id="newsletter_container">
        <div class="container margin_30">
            <div class="row">
                <div class="col-md-10 col-md-offset-1 text-center">
                    <h3>اشترك في النشرة الإخبارية للحصول على أحدث الأخبار</h3>
                    <div id="message-newsletter_2"></div>
                    <form method="post" action="#" name="epm-sign-up-form" id="newsletter_2" class="epm-sign-up-form">
                        <input name="epm-email" id="epm-email" type="email" value="<?php echo $epm_default_email_value ?>" placeholder="البريد الخاص بك" class="form-control email">
                        <input type="hidden" name="epm_submit" id="epm_submit" value="true">
                        <input type="hidden" name="epm_list_id" id="epm_list_id" value="<?php echo $list; ?>">
                        <input type="submit" name="epm-submit-chimp" value="اشترك" data-wait-text="انتظر من فضلك..." tabindex="10" class="newsletter-btn btn epm-sign-up-button epm-submit-chimp">
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- End newsletter_container -->
    <footer id="footer_3">
        <div class="container">

            <div class="row footer-links">

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <p>
                        <img src="<?php echo esc_url(CT_TEMPLATE_DIRECTORY_URI . '/imgs/logo.png') ?> " width="160" alt="Agazat Masr" data-retina="true" id="logo">
                    </p>

                    <ul class="social-links">
                        <?php
                        $social_links = array('facebook', 'twitter', 'google', 'instagram', 'pinterest', 'vimeo', 'youtube-play', 'linkedin');

                        foreach ($social_links as $social_link) :
                            if (!empty($ct_options[$social_link])) :
                        ?>
                                <li>
                                    <a href="<?php echo esc_url($ct_options[$social_link]) ?>" target="_black"><span class="fa fa-<?php echo esc_attr($social_link) ?>"></span></a>
                                </li>
                        <?php
                            endif;
                        endforeach;
                        ?>
                        <li>
                            <a href="https://instagram.com/agazat.masr?igshid=MmJiY2I4NDBkZg==" target="_black"><span class="fa fa-instagram"></span></a>
                        </li>
                        <li>
                            <a href="https://api.whatsapp.com/send/?phone=201225993443&text&type=phone_number&app_absent=0"  target="_black"><span class="fa fa-whatsapp" target="_black"></span></a>
                        </li>

                    </ul>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <?php if (is_active_sidebar('sidebar-footer-2')) : ?>
                        <?php dynamic_sidebar('sidebar-footer-2'); ?>
                    <?php endif; ?>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <?php if (is_active_sidebar('sidebar-footer-3')) : ?>
                        <?php dynamic_sidebar('sidebar-footer-3'); ?>
                    <?php endif; ?>
                </div>

                <div class="col-md-3 col-sm-3 col-xs-12 block">
                    <?php if (is_active_sidebar('sidebar-footer-4')) : ?>
                        <?php dynamic_sidebar('sidebar-footer-4'); ?>
                    <?php endif; ?>
					
                </div>

<!-- <div class="info-block">
                    <h4>العنوان</h4>
                    <ul>
						<li><span>أبراج المروة 2 برج رقم 1 شارع أحمد تيسير , الدور الثالث, مصر الجديدة,- القاهرة -جمهورية مصر العربية</span></li>
                        <li>البريد الالكترونى:  <a href="mailto:info@agazatmasr.com">info@agazatmasr.com</a></li>
                        <li>رقم الموبايل: <a href="tel:00201225993443">00201225993443</a></li>
                    </ul>
                </div> -->
                


            </div>
            <!-- End row -->

            <div class="row">
                <div class="col-md-12">
                    <div id="social_footer">

                        <div class="payment">
                            <img src="<?php echo esc_url(CT_TEMPLATE_DIRECTORY_URI . '/imgs/bank.png') ?> " alt="image" id="bank">
                            <img src="<?php echo esc_url(CT_TEMPLATE_DIRECTORY_URI . '/imgs/mastercard.png') ?> " alt="image">
                            <img src="<?php echo esc_url(CT_TEMPLATE_DIRECTORY_URI . '/imgs/visa.jpg') ?> " alt="image" id="visa">
                        </div>

                        <?php if (!empty($ct_options['copyright'])) { ?>

                            <p>&copy; <?php echo esc_html($ct_options['copyright']); ?></p>

                        <?php } ?>
                    </div>
                </div>
            </div><!-- End row -->

        </div><!-- End container -->
    </footer><!-- End footer -->

<?php endif; ?>

<div id="toTop"></div><!-- Back to top button -->
<div id="overlay"><i class="icon-spin3 animate-spin"></i></div>

<?php
wp_enqueue_style(
    'jquery-auto-complete',
    'https://cdnjs.cloudflare.com/ajax/libs/jquery-autocomplete/1.0.7/jquery.auto-complete.css',
    array(),
    '1.0.7'
);

wp_enqueue_script(
    'jquery-auto-complete',
    'https://cdnjs.cloudflare.com/ajax/libs/jquery-autocomplete/1.0.7/jquery.auto-complete.min.js',
    array('jquery'),
    '1.0.7',
    true
);
?>
<script type="text/javascript">
    jQuery(function($) {
        const queryString = window.location.search;
        const urlParams = new URLSearchParams(queryString);
        const districts = urlParams.get('districts')

        $('#search-hotel-form').validate({
            rules: {
                'country': {
                    required: function() {
                        return ($('#s').length == 0)
                    }
                },
                //                's': {
                //                    required: function () { return (($('#country').length == 0) && ($('#s').length == 0)); }
                //                },
            },
            messages: {
                country: {
                    required: 'هذا الحقل إلزامي'
                },
                cities: {
                    required: 'هذا الحقل إلزامي'
                },
                s: {
                    required: 'هذا الحقل إلزامي'
                },
            },
            errorPlacement: function(error, element) {
                element.css('border', 'solid 2px red');
            },
            submitHandler: function(form) { // for demo
                $("#search-hotel-form :input").each(function(index, obj) {
                    if ($(obj).val() == "") {
                        //                    $(obj).remove();
                        $(obj).attr("disabled", "disabled")
                    }
                });
                form.submit();
                return false;
            }
        });

        $('#search-tour-form').validate({
            rules: {
                //                's': {
                //                    required: true
                //                },
                'tour_types': {
                    required: true
                },
                //                'cities': {
                //                    required: true
                //                },

            },
            messages: {
                tour_types: {
                    required: 'هذا الحقل إلزامي'
                },
                //                cities: {required: 'هذا الحقل إلزامي'},
                //                s: {required: 'هذا الحقل إلزامي'},
            },
            errorPlacement: function(error, element) {
                element.css('border', 'solid 2px red');
            },
            submitHandler: function(form) { // for demo
                $("#search-tour-form :input").each(function(index, obj) {
                    if ($(obj).val() == "") {
                        //                    $(obj).remove();
                        $(obj).attr("disabled", "disabled")
                    }
                });
                form.submit();
                return false;
            }
        });

        if ($('#countries').val() !== "") {
            countryId = $('#countries').val();
            load_cities(countryId)
            $('.filter_type').show()
        }

        // load cities
        $('#countries').change(function() {
            countryId = $(this).val();
            load_cities(countryId)
        })

        function load_cities(countryId) {
            $.ajax({
                type: "POST",
                dataType: "json",
                url: ajaxurl,
                data: {
                    action: "get_districts_byparent",
                    'country_id': countryId
                },
                success: function(response) {
                    var options = '<option value="" selected><?php esc_html_e('Select city', 'citytours') ?></option>';
                    $.each(response.districts, function(index, item) {
                        if (districts == item['term_id']) {
                            options += '<option value="' + item['term_id'] + '" selected>' + item['name'] + '</option>';
                        } else {
                            options += '<option value="' + item['term_id'] + '">' + item['name'] + '</option>';
                        }
                    });

                    $('#cities').html(options);
                    $('#cities').prop("disabled", false);
                }
            });
        }

        // load cities
        $('#tour_types').change(function() {
            var tour_type = $(this).val();
            getTourCities(tour_type);
        })

        function getTourCities(tour_type) {
            $.ajax({
                type: "POST",
                dataType: "json",
                url: ajaxurl,
                data: {
                    action: "get_tour_type_cities",
                    'tour_type': tour_type
                },
                success: function(response) {
                    if (response.success == 1) {
                        var options = '<option value="" selected><?php esc_html_e('Select city', 'citytours') ?></option>';

                        $.each(response.cities, function(index, item) {
                            options += '<option value="' + item['term_id'] + '">' + item['name'] + '</option>';
                        });

                        $('#tour_city').html(options);
                        $('#tour_city').prop("disabled", false);
                    }
                }
            });
        }

        function getTourCities(tour_type) {
            $.ajax({
                type: "POST",
                dataType: "json",
                url: ajaxurl,
                data: {
                    action: "get_tour_type_cities",
                    'tour_type': tour_type
                },
                success: function(response) {
                    if (response.success == 1) {
                        var options = '<option value="" selected><?php esc_html_e('Select city', 'citytours') ?></option>';

                        $.each(response.cities, function(index, item) {
                            options += '<option value="' + item['term_id'] + '">' + item['name'] + '</option>';
                        });

                        $('#tour_city').html(options);
                        $('#tour_city').prop("disabled", false);
                    }
                }
            });
        }

        var searchRequest;
        $('#hotel_name').autoComplete({
            minChars: 1,
            delay: 0,
            source: function(term, suggest) {
                try {
                    searchRequest.abort();
                } catch (e) {}

                countryId = $('#search-hotel-form select[name=country]').val();
                districts = $('#search-hotel-form select[name=districts]').val();

                searchRequest = $.post(ajaxurl, {
                    search: term,
                    country: countryId,
                    districts: districts,
                    action: 'ct_hotel_ajax_search'
                }, function(res) {
                    suggest(res.data);
                });
            }
        });

        $('.open_close').on("click", function() {
            $('.main-menu').toggleClass('show');
        });

        // $('.open_close').on("click", function(){
        //     $('.main-menu').removeClass('show');
        // })

    });
</script>
<?php
if (is_tag() || is_category() || is_archive()) {
    wp_enqueue_style('blog', CT_TEMPLATE_DIRECTORY_URI . '/css/blog.css');
}
wp_footer(); ?>
</body>

</html>
